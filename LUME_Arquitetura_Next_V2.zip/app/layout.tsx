export const metadata = {
  title: "LUME Arquitetura",
  description: "Arquitetura contemporânea e projetos exclusivos."
};

export default function Layout({children}:{children:React.ReactNode}){
 return (
  <html lang="pt-BR">
   <body>{children}</body>
  </html>
 )
}