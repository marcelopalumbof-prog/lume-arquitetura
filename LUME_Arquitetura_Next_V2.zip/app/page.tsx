import Hero from "@/components/Hero";
import Projects from "@/components/Projects";

export default function Home(){
 return (
  <main>
   <Hero/>
   <section className="section">
    <h2>Arquitetura não é apenas construir.<br/>É criar experiências.</h2>
    <p>Criamos espaços exclusivos com identidade, conforto e sofisticação.</p>
   </section>
   <Projects/>
   <section className="section dark">
    <h2>Seu espaço merece ser pensado nos mínimos detalhes.</h2>
    <button>Agendar conversa</button>
   </section>
  </main>
 )
}