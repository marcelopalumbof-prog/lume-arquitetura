import {motion} from "framer-motion";

export default function Hero(){
 return (
  <section className="hero">
   <div className="bg"/>
   <motion.div 
    className="content"
    initial={{opacity:0,y:50}}
    animate={{opacity:1,y:0}}
    transition={{duration:1}}
   >
    <h1>Projetamos espaços que transformam sonhos em arquitetura.</h1>
    <p>Projetos residenciais contemporâneos para pessoas que valorizam viver bem.</p>
    <button>Solicitar projeto</button>
   </motion.div>
  </section>
 )
}