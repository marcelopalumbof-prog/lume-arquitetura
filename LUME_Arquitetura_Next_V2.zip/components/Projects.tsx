import {motion} from "framer-motion";

const projects=[
"Casa Horizonte",
"Apartamento Jardins",
"Residência Vale"
];

export default function Projects(){
return <section className="cards">
{projects.map((p)=>
<motion.div whileHover={{scale:1.04}} key={p}>
<h3>{p}</h3>
<p>Design sofisticado, materiais naturais e arquitetura personalizada.</p>
</motion.div>
)}
</section>
}